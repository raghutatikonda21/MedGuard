"""
MedGuard Advanced Medication Safety Engine.

This is an educational clinical-decision-support prototype. It is NOT a
diagnosis or prescribing system and must not be used as a substitute for
professional clinical judgment.
"""
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import json, re
from typing import Any

BASE = Path(__file__).resolve().parent
with open(BASE / "medication_knowledge.json", encoding="utf-8") as f:
    KB = json.load(f)

MEDS = KB["medications"]
INTERACTIONS = KB["interactions"]

ALIASES = {}
for canonical, data in MEDS.items():
    for alias in data.get("aliases", []):
        ALIASES[alias.casefold()] = canonical

def normalize_medication_name(name: str) -> str:
    if not isinstance(name, str):
        raise TypeError("Medication name must be a string.")
    x = re.sub(r"\s+", " ", name).strip().casefold()
    return ALIASES.get(x, x)

def medication_info(name: str) -> dict[str, Any] | None:
    return MEDS.get(normalize_medication_name(name))

def find_repeated_entries(names: list[str]) -> list[dict]:
    grouped = defaultdict(list)
    for name in names:
        n = normalize_medication_name(name)
        if n:
            grouped[n].append(name.strip())
    return [
        {"normalized_name": n, "entries": entries, "count": len(entries),
         "review_required": True,
         "message": "Repeated medication entry detected; verify strength and active ingredient."}
        for n, entries in grouped.items() if len(entries) > 1
    ]

def _norm_text(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").casefold()).strip()

def _condition_matches(condition: str, key: str) -> bool:
    c = _norm_text(condition)
    return key in c or c in key

def _parse_mg(dose: str) -> float | None:
    m = re.search(r"(\d+(?:\.\d+)?)\s*(mg|mcg|g)\b", _norm_text(dose))
    if not m: return None
    value = float(m.group(1))
    unit = m.group(2)
    if unit == "g": value *= 1000
    if unit == "mcg": value /= 1000
    return value

def _frequency_per_day(freq: str) -> float | None:
    f = _norm_text(freq)
    if not f: return None
    if "once" in f or "daily" in f and "twice" not in f and "three" not in f and "four" not in f:
        return 1.0
    if "twice" in f or "2 times" in f or "bid" in f: return 2.0
    if "three" in f or "3 times" in f or "tid" in f: return 3.0
    if "four" in f or "4 times" in f or "qid" in f: return 4.0
    m = re.search(r"every\s+(\d+)\s*hours?", f)
    if m and int(m.group(1)) > 0: return 24 / int(m.group(1))
    return None

def analyze(patient: dict, medications: list[dict]) -> dict:
    risks: list[dict] = []
    normalized = [normalize_medication_name(m["name"]) for m in medications]
    names = [m["name"].strip() for m in medications]

    def add(severity, title, reason, meds, category, confidence="moderate", evidence=""):
        risks.append({
            "severity": severity, "title": title, "reason": reason,
            "medications": meds, "category": category,
            "confidence": confidence, "evidence": evidence
        })

    # Unknown-medication transparency.
    for raw, n in zip(names, normalized):
        if n not in MEDS:
            add("LOW", "Medication not in local knowledge base",
                f"'{raw}' was not found in the prototype knowledge base. No conclusion about safety can be made from this absence.",
                [raw], "coverage", "high",
                "Knowledge-base coverage limitation")

    # Duplicate exact/alias names.
    for item in find_repeated_entries(names):
        add("MEDIUM", "Possible duplicate medication",
            "The same normalized medicine appears more than once. Verify active ingredient, strength and instructions.",
            item["entries"], "duplicate", "high", "Local medication normalization")

    # Duplicate therapeutic class.
    classes = defaultdict(list)
    for raw, n in zip(names, normalized):
        info = MEDS.get(n)
        if info:
            classes[info["class"]].append(raw)
    for cls, entries in classes.items():
        if len(entries) > 1 and "NSAID" in cls:
            add("HIGH", "Duplicate NSAID therapy",
                "More than one NSAID is present. Combined use can increase gastrointestinal, renal and bleeding toxicity.",
                entries, "duplicate_class", "high", "Medication-class rule")

    # Pairwise interactions.
    for i in range(len(normalized)):
        for j in range(i + 1, len(normalized)):
            a, b = normalized[i], normalized[j]
            for rule in INTERACTIONS:
                if {a,b} == {rule["a"], rule["b"]}:
                    add(rule["severity"], rule["title"], rule["reason"],
                        [names[i], names[j]], rule["category"], "high",
                        "Medication interaction knowledge base")

    # Allergy / class cross-reactivity screening.
    allergies = patient.get("allergies", [])
    for allergy in allergies:
        an = _norm_text(allergy)
        if not an: continue
        for raw, n in zip(names, normalized):
            info = MEDS.get(n)
            if not info: continue
            groups = [x.casefold() for x in info.get("allergy_groups", [])]
            direct = an in groups or n == an
            penicillin_beta = an in {"penicillin", "penicillins", "beta-lactam", "beta lactam"} and n == "amoxicillin"
            if direct or penicillin_beta:
                add("HIGH", "Potential medication-allergy conflict",
                    f"The patient record lists '{allergy}', which may be relevant to '{raw}'. Verify the exact previous reaction and allergy history with a qualified clinician.",
                    [raw], "allergy", "high",
                    "Medication labeling / allergy-group rule")

    # Condition-specific rules.
    for condition in patient.get("conditions", []):
        for raw, n in zip(names, normalized):
            info = MEDS.get(n)
            if not info: continue
            for key, (sev, reason) in info.get("conditions", {}).items():
                if _condition_matches(condition, key):
                    add(sev, "Medication-condition concern", reason,
                        [raw], "condition", "moderate",
                        f"Knowledge-base condition rule: {key}")

    # Age-based safety prompts.
    age = int(patient.get("age", 0))
    if age >= 65 and len(medications) >= 4:
        add("MEDIUM", "Polypharmacy review",
            f"{len(medications)} medication entries are recorded for a patient aged {age}. A structured medication review can help identify interactions, duplication and monitoring needs.",
            names, "patient_factor", "moderate", "Age + medication-count heuristic")
    if age < 18:
        add("LOW", "Pediatric dosing requires weight/context",
            "The prototype cannot safely validate pediatric dosing without weight, indication, formulation and current reference dosing.",
            names, "dose", "high", "Missing clinical dosing inputs")

    # Dose/frequency plausibility for selected prototype drugs.
    for med in medications:
        n = normalize_medication_name(med["name"])
        mg = _parse_mg(med.get("dose", ""))
        freq = _frequency_per_day(med.get("frequency", ""))
        if n == "amoxicillin" and mg is not None and freq is not None and age >= 18:
            daily = mg * freq
            if daily < 500 or daily > 4000:
                add("MEDIUM", "Amoxicillin dose/frequency needs verification",
                    f"The entered regimen implies approximately {daily:g} mg/day. Adult dosing varies by indication and formulation; verify against the prescription and current labeling.",
                    [med["name"]], "dose", "moderate",
                    "Prototype plausibility range; indication/formulation not known")
        if n == "metformin" and mg is not None and mg > 2000:
            add("MEDIUM", "Metformin dose requires verification",
                "The entered strength is above a common tablet strength and should be verified with the actual product, regimen and prescribing instructions.",
                [med["name"]], "dose", "moderate",
                "Prototype strength check")

    # Data completeness / missing context.
    if any(not m.get("dose") or not m.get("frequency") for m in medications):
        add("LOW", "Incomplete medication instructions",
            "One or more medication entries are missing dose or frequency, limiting automated safety screening.",
            [m["name"] for m in medications if not m.get("dose") or not m.get("frequency")],
            "data_quality", "high", "Input completeness check")

    # Score: transparent heuristic, not a medical risk probability.
    weights = {"HIGH": 30, "MEDIUM": 12, "LOW": 4}
    penalty = min(100, sum(weights.get(r["severity"], 0) for r in risks))
    score = max(0, 100 - penalty)
    level = "HIGH" if penalty >= 30 else ("MODERATE" if penalty >= 12 else ("LOW" if penalty else "NO_FLAGS"))

    category_counts = defaultdict(int)
    for r in risks: category_counts[r["category"]] += 1

    return {
        "risks": risks,
        "risk_count": len(risks),
        "safety_score": score,
        "risk_level": level,
        "category_counts": dict(category_counts),
        "knowledge_base_version": KB.get("version"),
        "coverage": {
            "known_medications": len(MEDS),
            "interaction_rules": len(INTERACTIONS),
            "note": "Absence of an alert does not prove a medication regimen is safe."
        }
    }
