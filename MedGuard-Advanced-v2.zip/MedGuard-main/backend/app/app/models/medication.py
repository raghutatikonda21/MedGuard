from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Medication(Base):
    __tablename__ = "medications"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    medicine_name: Mapped[str] = mapped_column(
        String(200),
        nullable=False
    )

    generic_name: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True
    )

    dosage: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    frequency: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    route: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    purpose: Mapped[str | None] = mapped_column(
        Text,
        nullable=True
    )

    start_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True
    )

    end_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True
    )

    is_current: Mapped[bool] = mapped_column(
        default=True
    )

    prescribed_by: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True
    )

    notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    