from fastapi import FastAPI

app = FastAPI(
    title="MedGuard API",
    description="Patient-focused medication safety and medical record analysis platform",
    version="0.1.0",
)


@app.get("/")
def root():
    return {
        "application": "MedGuard",
        "message": "MedGuard API is running",
        "version": "0.1.0",
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy"
    }