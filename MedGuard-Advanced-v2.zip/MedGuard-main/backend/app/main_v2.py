from datetime import datetime
from pathlib import Path
import json, re, sqlite3

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from medication_engine import analyze, MEDS, INTERACTIONS, normalize_medication_name

app = FastAPI(
    title="MedGuard Advanced API",
    description="Medication safety screening, explainable risk scoring and report management",
    version="2.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500","http://localhost:5500"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)
BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "medguard.db"

def get_connection():
    c = sqlite3.connect(DATABASE); c.row_factory = sqlite3.Row; return c

def initialize_database():
    with get_connection() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS patients(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER NOT NULL,
            allergies TEXT DEFAULT '', conditions TEXT DEFAULT '', created_at TEXT NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT, patient_name TEXT NOT NULL,
            medication_count INTEGER NOT NULL, risk_count INTEGER NOT NULL,
            report_json TEXT NOT NULL, created_at TEXT NOT NULL)""")
initialize_database()

class PatientInput(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    age: int = Field(ge=0, le=120)
    allergies: list[str] = Field(default_factory=list)
    conditions: list[str] = Field(default_factory=list)

class MedicationInput(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    dose: str = Field(default="", max_length=100)
    frequency: str = Field(default="", max_length=100)

class AnalysisInput(BaseModel):
    patient: PatientInput
    medications: list[MedicationInput] = Field(default_factory=list)

class PrescriptionInput(BaseModel):
    text: str = Field(min_length=1, max_length=20000)

@app.get("/")
def home():
    return {"status":"ok","application":"MedGuard Advanced","version":"2.0.0",
            "features":["knowledge-base","drug-interactions","allergy-screening","condition-screening","risk-scoring","explainable-alerts"]}

@app.get("/api/health")
def health():
    with get_connection() as c: c.execute("SELECT 1").fetchone()
    return {"status":"healthy","database":"connected","knowledge_base":len(MEDS),"interaction_rules":len(INTERACTIONS)}

def split_list(v): return [x for x in (v or "").split("|") if x]

@app.get("/api/patients")
def get_patients():
    with get_connection() as c: rows=c.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    return [{"id":r["id"],"name":r["name"],"age":r["age"],
             "allergies":split_list(r["allergies"]),"conditions":split_list(r["conditions"]),
             "created_at":r["created_at"]} for r in rows]

@app.post("/api/patients")
def create_patient(p: PatientInput):
    name=p.name.strip()
    if not name: raise HTTPException(422,"Patient name cannot be empty.")
    allergies=[x.strip() for x in p.allergies if x.strip()]
    conditions=[x.strip() for x in p.conditions if x.strip()]
    now=datetime.now().isoformat(timespec="seconds")
    with get_connection() as c:
        cur=c.execute("INSERT INTO patients(name,age,allergies,conditions,created_at) VALUES(?,?,?,?,?)",
                      (name,p.age,"|".join(allergies),"|".join(conditions),now))
        pid=cur.lastrowid
    return {"success":True,"message":"Patient profile saved","id":pid}

@app.put("/api/patients/{patient_id}")
def update_patient(patient_id:int,p:PatientInput):
    name=p.name.strip()
    with get_connection() as c:
        cur=c.execute("UPDATE patients SET name=?,age=?,allergies=?,conditions=? WHERE id=?",
                      (name,p.age,"|".join(x.strip() for x in p.allergies if x.strip()),
                       "|".join(x.strip() for x in p.conditions if x.strip()),patient_id))
        if cur.rowcount==0: raise HTTPException(404,"Patient not found.")
    return {"success":True,"message":"Patient profile updated"}

@app.delete("/api/patients/{patient_id}")
def delete_patient(patient_id:int):
    with get_connection() as c:
        cur=c.execute("DELETE FROM patients WHERE id=?",(patient_id,))
        if cur.rowcount==0: raise HTTPException(404,"Patient not found.")
    return {"success":True,"message":"Patient deleted"}

@app.get("/api/knowledge/medications")
def knowledge_medications():
    return {"count":len(MEDS),"medications":[
        {"name":n,"class":v["class"],"uses":v.get("uses",[]),"notes":v.get("notes","")}
        for n,v in MEDS.items()]}

@app.get("/api/knowledge/interactions")
def knowledge_interactions():
    return {"count":len(INTERACTIONS),"interactions":INTERACTIONS}

@app.get("/api/knowledge/search")
def knowledge_search(q:str=""):
    q=q.casefold().strip()
    results=[]
    for n,v in MEDS.items():
        hay=" ".join([n,v["class"]," ".join(v.get("aliases",[]))," ".join(v.get("uses",[]))]).casefold()
        if q in hay:
            results.append({"name":n,"class":v["class"],"uses":v.get("uses",[]),"notes":v.get("notes","")})
    return {"query":q,"results":results[:25]}

@app.post("/api/prescription/extract")
def extract_prescription(data:PrescriptionInput):
    text=data.text.casefold(); found=[]
    for canonical, info in MEDS.items():
        aliases=sorted(info.get("aliases",[]),key=len,reverse=True)
        if any(re.search(r"\b"+re.escape(a.casefold())+r"\b",text) for a in aliases):
            found.append({"name":canonical.title(),"dose":"","frequency":""})
    return {"success":True,"medications_found":len(found),"medications":found,
            "notice":"Prototype text extraction only. Verify all medicines, strengths and instructions against the original prescription."}

@app.post("/api/analyze")
def analyze_medications(data:AnalysisInput):
    if not data.medications: raise HTTPException(422,"At least one medication is required.")
    patient=data.patient.model_dump()
    meds=[m.model_dump() for m in data.medications]
    result=analyze(patient,meds)
    now=datetime.now().isoformat(timespec="seconds")
    report={"patient_name":patient["name"].strip(),"patient_age":patient["age"],
            "analyzed_at":now,"medication_count":len(meds),"medications":meds,**result,
            "notice":"Educational decision-support prototype. Alerts are not diagnoses or prescribing instructions. Verify with a qualified doctor or pharmacist."}
    with get_connection() as c:
        c.execute("INSERT INTO reports(patient_name,medication_count,risk_count,report_json,created_at) VALUES(?,?,?,?,?)",
                  (patient["name"].strip(),len(meds),len(result["risks"]),json.dumps(report),now))
    return report

@app.get("/api/reports")
def get_reports():
    with get_connection() as c:
        rows=c.execute("SELECT id,patient_name,medication_count,risk_count,report_json,created_at FROM reports ORDER BY id DESC").fetchall()
    out=[]
    for r in rows:
        try: report=json.loads(r["report_json"])
        except: report={}
        out.append({"id":r["id"],"patient_name":r["patient_name"],"medication_count":r["medication_count"],
                    "risk_count":r["risk_count"],"created_at":r["created_at"],"report":report})
    return out

@app.delete("/api/reports/{report_id}")
def delete_report(report_id:int):
    with get_connection() as c:
        cur=c.execute("DELETE FROM reports WHERE id=?",(report_id,))
        if cur.rowcount==0: raise HTTPException(404,"Report not found.")
    return {"success":True,"message":"Report deleted"}
