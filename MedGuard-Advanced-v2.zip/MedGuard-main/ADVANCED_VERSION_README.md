# MedGuard Advanced v2.0

MedGuard is an educational medication-safety decision-support prototype.

## Advanced capabilities
- Medication knowledge base with 16 common medicines/classes
- Alias/brand-name normalization
- Drug-drug interaction screening
- Allergy and medication-class screening
- Drug-condition screening
- Duplicate medicine and duplicate NSAID detection
- Age/polypharmacy heuristics
- Selected dose/frequency plausibility checks
- Explainable alerts with category, confidence and evidence basis
- Transparent 0–100 heuristic safety score
- Knowledge-base search APIs
- Prescription text extraction prototype
- Persistent patient and report history

## Run
```powershell
cd backendpp
python -m uvicorn main_v2:app --reload
```

Open `frontend\MedGuard_frontend_v5.html` with a local static server such as VS Code Live Server.

## Demo scenario
Patient: Demo Patient A
Age: 72
Allergy: Penicillin
Condition: Kidney Disease

Medicines:
- Warfarin 5 mg once daily
- Ibuprofen 200 mg as needed
- Amoxicillin 500 mg three times daily
- Paracetamol 500 mg as needed
- Acetaminophen 500 mg as needed

This should demonstrate multiple independent screening pathways.

## Safety
This is not a diagnostic, prescribing, or emergency medical system. A missing alert does not mean a medication regimen is safe. The knowledge base is a demonstration dataset and must be verified against current official product labeling and clinical references before any real-world use.
